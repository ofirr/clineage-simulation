function [ newGen ] = update_generation( Gen )
% updates the generation
    
    newGen = Gen + 1;

end

